#include "stdafx.h"
#include "TileMap.h"
#include "Tile.h"
#include "NormalTile.h"
#include "rapidcsv.h"

TileMap::TileMap(const std::string& textureId, const std::string& n)
    : GameObject(n)
{
}

TileMap::~TileMap()
{
}

bool TileMap::Load(const std::string& filePath)
{
    rapidcsv::Document map(filePath, rapidcsv::LabelParams(-1, -1));
    sf::Vector2i size = { (int)map.GetColumnCount(), (int)map.GetRowCount() };
    sf::Vector2f tileSize = { 32.f, 32.f };
    sf::Vector2f offsets[4] =
    {
        { 0.f, 0.f },
        { tileSize.x, 0.f },
        { tileSize.x, tileSize.y },
        { 0.f, tileSize.y }
    };
    sf::Vector2f startPos = { 0, 0 };
    sf::Vector2f currPos = startPos;
    for (int i = 0; i < size.y; ++i)
    {
        for (int j = 0; j < size.x; ++j)
        {
            Tile::Types type = (Tile::Types)map.GetCell<int>(j, i);
            switch (type)
            {
            case Tile::Types::None:
                break;
            case Tile::Types::Normal:
            {
                Tile* tile = new NormalTile("graphics/Blocks/Block001.png");
                tile->SetPosition(currPos);
                tiles.push_back(tile);
            }
                break;
            case Tile::Types::Killer:

                break;
            case Tile::Types::Througth:
                break;
            case Tile::Types::Fake:
                break;
            default:
                break;
            }
            currPos.x += tileSize.x;
        }
        currPos.y += tileSize.y;
    }

    return true;
}

void TileMap::Init()
{
}

void TileMap::Reset()
{
}

void TileMap::Update(float deltaTime)
{
}

void TileMap::Draw(sf::RenderWindow& window)
{
    for (auto tile : tiles)
    {
        if ((int)tile->GetType() == 1)
        {
            std::cout << (int)tile->GetType() << std::endl;
        }
        tile->Draw(window);
    }
}


