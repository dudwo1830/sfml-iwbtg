#pragma once
#include "GameObject.h"

class Tile;

class TileMap : public GameObject
{
protected:
	std::vector<Tile*> tiles;

public:
	TileMap(const std::string& textureId = "", const std::string& n = "");
	virtual ~TileMap() override;

	bool Load(const std::string& filePath);
	

	virtual void Init() override;
	virtual void Reset() override;
	virtual void Update(float deltaTime) override;
	virtual void Draw(sf::RenderWindow& window);
};

