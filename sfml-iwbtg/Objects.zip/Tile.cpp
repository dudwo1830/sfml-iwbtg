#include "stdafx.h"
#include "Tile.h"
#include "Player.h"

Tile::Tile(const std::string& textureId, const std::string& name)
    :VertexArrayGo(textureId, name)
{
}

Tile::~Tile()
{
    Release();
}

void Tile::Reset()
{
    VertexArrayGo::Reset();
}

void Tile::Update(float deltaTime)
{
    VertexArrayGo::Update(deltaTime);
}

void Tile::Draw(sf::RenderWindow& window)
{
    VertexArrayGo::Draw(window);
}


const Tile::Types Tile::GetType()
{
    return type;
}

void Tile::SetType(Types type)
{
    this->type = type;
}
