#pragma once
#include "VertexArrayGo.h"

class Tile : public VertexArrayGo
{
public:
	enum class Types {
		None = -1,
		Normal,
		Killer,
		Througth,
		Fake
	};

protected:
	Types type = Types::None;
	
	std::function<void()> CollideTop;
	std::function<void()> CollideLeft;
	std::function<void()> CollideRight;
	std::function<void()> CollideBottom;

	Tile(const Tile& other) = delete;
	bool operator==(const Tile& other) const = delete;
public:
	Tile(const std::string& textureId = "", const std::string& name = "");
	virtual ~Tile();

	virtual void Reset() override;
	virtual void Update(float deltaTime) override;
	virtual void Draw(sf::RenderWindow& window) override;

	const Types GetType();
	void SetType(Types type);
};

